<?php $__env->startSection('content'); ?>
<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('dangnhap')); ?>" method="post" class="beta-form-checkout">
            <?php echo e(csrf_field()); ?> 
				<div class="row">
					<div class="col-sm-3">
                        <?php if(Session::has('flag')): ?>
                            <div class="alert alert-<?php echo e(Session::get('flag')); ?>"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>
                    </div>
					<div class="col-sm-6">
						<h4>Đăng nhập</h4>
						<div class="space20">&nbsp;</div>

						
						<div class="form-block">
							<label for="email">Email</label>
                            <input type="email" id="email" name="email">
                            <?php if($errors->has('email')): ?>
                                <div class="text-danger">
                                    <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($err); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                             <?php endif; ?>
						</div>
						<div class="form-block">
							<label for="phone">Mật Khẩu</label>
                            <input type="password" id="password" name="password">
                            <?php if($errors->has('password')): ?>
                                <div class="text-danger">
                                    <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($err); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                             <?php endif; ?>
						</div>
						<div class="form-block">
							<button type="submit" class="btn btn-primary">Login</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>