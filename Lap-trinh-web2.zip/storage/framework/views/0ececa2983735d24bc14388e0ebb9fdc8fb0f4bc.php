<?php $__env->startSection('content'); ?>
<div class="fullwidthbanner-container">
				<div class="fullwidthbanner">
					<div class="bannercontainer" >
					<div class="banner" >
							<ul>
								<!-- THE FIRST SLIDE -->
						
							<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li data-transition="boxfade" data-slotamount="20" class="active-revslide current-sr-slide-visible" style="width: 100%; height: 100%; overflow: hidden; visibility: inherit; opacity: 1; z-index: 20;">
									<div class="slotholder" style="width:100%;height:100%;" data-duration="undefined" data-zoomstart="undefined" data-zoomend="undefined" data-rotationstart="undefined" data-rotationend="undefined" data-ease="undefined" data-bgpositionend="undefined" data-bgposition="undefined" data-kenburns="undefined" data-easeme="undefined" data-bgfit="undefined" data-bgfitend="undefined" data-owidth="undefined" data-oheight="undefined">
													<div class="tp-bgimg defaultimg" data-lazyload="undefined" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" data-lazydone="undefined" src="Source/image/slide/<?php echo e($l->image); ?>" data-src="Source/image/slide/<?php echo e($l->image); ?>" style="background-color: rgba(0, 0, 0, 0); background-repeat: no-repeat; background-image: url('Source/image/slide/<?php echo e($l->image); ?>'); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit;">
												</div>
									</div>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>

					<div class="tp-bannertimer"></div>
				</div>
			</div>
			<!--slider-->
</div>
<div class="container">
	<div id="content" class="space-top-none">
		<div class="main-content">
			<div class="space60">&nbsp;</div>
			<div class="row">
				<div class="col-sm-12">
					<div class="beta-products-list">
						<h4>Sản Phẩm Mới</h4>
						<div class="beta-products-details">
							<p class="pull-left">Tìm thấy <?php echo e(count($new_product)); ?> sản phẩm</p>
							<div class="clearfix"></div>
						</div>

						<div class="row">
							<?php $__currentLoopData = $new_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-3">
								<div class="single-item">
									<div class="single-item-header">
										<a href="<?php echo e(route('chitietsanpham',$sp->id)); ?>"><img src="Source/image/product/<?php echo e($sp->image); ?> " alt="" height="298px"></a>
									</div>
									<div class="single-item-body">
										<p class="single-item-title"><?php echo e($sp->name); ?></p>
										<p class="single-item-price">
											<?php if($sp->promotion_price == 0): ?>
												<span class="flash-sale"><?php echo e($sp->unit_price); ?></span>
											<?php else: ?>
												<span class="flash-del"><?php echo e($sp->unit_price); ?></span>
												<span class="flash-sale"><?php echo e($sp->promotion_price); ?></span>
											<?php endif; ?>
										</p>
									</div>
									<div class="single-item-caption">
										<a class="add-to-cart pull-left" href="<?php echo e(route('themgiohang',$sp->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
										<a class="beta-btn primary" href="<?php echo e(route('themgiohang',$sp->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
										<div class="clearfix"></div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="row"><?php echo e($new_product->links()); ?></div>
					</div> <!-- .beta-products-list -->

					<div class="space50">&nbsp;</div>

					<div class="beta-products-list">
						<h4>Sản Phẩm Khuyến Mãi</h4>
						<div class="beta-products-details">
							<p class="pull-left">Tìm thấy <?php echo e(count($sale)); ?> sản phẩm</p>
							<div class="clearfix"></div>
						</div>
						<div class="row">
							<?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-3">
								<div class="single-item">
									<div class="single-item-header">
										<a href="<?php echo e(route('chitietsanpham',$l->id)); ?>"><img src="Source/image/product/<?php echo e($l->image); ?>" alt="" height="298px"></a>
									</div>
									<div class="single-item-body">
										<p class="single-item-title"><?php echo e($l->name); ?></p>
										<p class="single-item-price">
											<?php if($l->promotion_price == 0): ?>
												<span class="flash-sale"><?php echo e($l->unit_price); ?></span>
											<?php else: ?>
												<span class="flash-del"><?php echo e($l->unit_price); ?></span>
												<span class="flash-sale"><?php echo e($l->promotion_price); ?></span>
											<?php endif; ?>
										</p>
									</div>
									<div class="single-item-caption">
										<a class="add-to-cart pull-left" href="<?php echo e(route('themgiohang',$l->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
										<a class="beta-btn primary" href="<?php echo e(route('themgiohang',$l->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
										<div class="clearfix"></div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="row"><?php echo e($sale->links()); ?></div>
						<div class="space40">&nbsp;</div>
						
					</div> <!-- .beta-products-list -->
				</div>
			</div> <!-- end section with sidebar and main content -->


		</div> <!-- .main-content -->
	</div> <!-- #content -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>